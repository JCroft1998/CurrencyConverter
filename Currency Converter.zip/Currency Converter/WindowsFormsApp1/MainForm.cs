﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class MainForm : Form
    {

        /// <summary>
        /// This is the forms method, the combo box's have been set to dropdownlist only
        /// Tool tips have been set on the buttons 
        /// </summary>
        public MainForm()
        {
            InitializeComponent();
            cboFromCurrency.DropDownStyle = ComboBoxStyle.DropDownList;
            coboTo.DropDownStyle = ComboBoxStyle.DropDownList;
            ToolTip tooltip = new ToolTip();
            tooltip.SetToolTip(btnConvert, "Click Here To Convert");
            tooltip.SetToolTip(btnclear, "Clear Amount");
            tooltip.SetToolTip(btnConvert, "Export Exchange Rate");

        }
        /// <summary>
        /// This method is for the convert button, this includes the values of the exchange rates
        /// This method will check to see if the combo boxes have been selected eg GBP to USD 
        /// It will do british pound which is the value in the txt box * the currency 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnConvert_Click(object sender, EventArgs e)
        {
            
            double USD = 1.29;
            double AUD = 1.96;
            double EUR = 1.15;
           

            try
            {
                double british_pound = double.Parse(txtAmount.Text);

                if (cboFromCurrency.Text == "GBP" && coboTo.Text == "USD")
                {
                  lblTotal.Text = string.Format("GBP to USD $ {0}", british_pound * USD);

                }
                else if (cboFromCurrency.Text == "GBP" && coboTo.Text == "AUD")
                {
                    lblTotal.Text = string.Format("GBP to AUD $ {0}", british_pound * AUD);


                }
                else if (cboFromCurrency.Text == "GBP" && coboTo.Text == "EUR")
                {
                    lblTotal.Text = string.Format("GBP to EUR $ {0}", british_pound * EUR);


                }
            }
            catch (Exception)
            {
                MessageBox.Show("Please Enter a number", "Error", MessageBoxButtons.OKCancel, MessageBoxIcon.Error);


            }



        }

/// <summary>
/// This button clears the txtbox for currency 
/// </summary>
/// <param name="sender"></param>
/// <param name="e"></param>
        private void btnclear_Click(object sender, EventArgs e)
        {
            txtAmount.Clear();
            
        }
        /// <summary>
        /// This method exports the currency to txt file in the directory called logs 
        /// </summary>
        public void Export()
        {
            
         
            try
            {



                string generated = DateTime.Now.ToString(" ddMMyyyy-hhmmss ");
                string savePath = Directory.GetParent(Environment.CurrentDirectory).Parent.FullName + Path.DirectorySeparatorChar + "Logs" + Path.DirectorySeparatorChar + generated + ".txt";
                string filepath = coboTo.Text;
                // Writes the text to the file
                TextWriter write = new StreamWriter(savePath);
                write.Write("Date For Current Exchange Rate---" + "\n");
                write.Write(DateTime.Now + "\n");
                write.Write("Logs For Currency ---" + "\n");
                
                write.Write("GBP: £"+ txtAmount.Text + lblTotal.Text);

                write.Close();
                MessageBox.Show("Exported Successfully");
            }
            
            
          catch (Exception)
            {
                MessageBox.Show("Exported Unsuccessful");




            }

        }

        /// <summary>
        /// This method is the button method to export to the text file, there is validation here 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnExport_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtAmount.Text))
            {
                MessageBox.Show("Error Please Enter Amount");
            }
            else
            {
                Export();
            }
           
        }

        private void txtAmount_TextChanged(object sender, EventArgs e)
        {
           
        }
    }
}







    

